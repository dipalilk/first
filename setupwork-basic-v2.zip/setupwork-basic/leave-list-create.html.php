<?php include("headmain.html.php"); ?>

<script src="leave-list-create.js"></script>
<script src="js/angular-sanitize.js"></script>
<style>
table, th , td {
  border: 1px solid grey;
  border-collapse: collapse;
  padding: 5px;
}
table tr:nth-child(odd) {
  background-color: #f1f1f1;
}
table tr:nth-child(even) {
  background-color: #ffffff;
}
</style>
<div class="content-main" ng-app="myApp" ng-controller="myCtrl" id="idMyCtrl" ng-cloak >
	<div ng-model="myProgressBar" class="progress" ng-show="disableFlag">
		<div class="progress-bar progress-bar-striped active" role="progressbar" style="width:100%">In Progress...</div>
	</div>		

	<div class="grid-form1">
		<h3>Apply Leave Form</h3>
		<div class="tab-content">
			<div class="tab-pane active">
				<form class="form-horizontal">
                <div class="form-group"><label for="idLeaveListFromDate" class="col-sm-2 control-label">From Date</label><div class="col-sm-3"><input type="date" ng-model="LeaveListFromDate" class="form-control1" id="idLeaveListFromDate" placeholder="From Date"></div></div>
                <div class="form-group"><label for="idLeaveListToDate" class="col-sm-2 control-label">To Date</label><div class="col-sm-3"><input type="date" ng-model="LeaveListToDate" class="form-control1" id="idLeaveListToDate" placeholder="To Date"></div></div>
                <div class="form-group"><label for="idLeaveListTypeID" class="col-sm-2 control-label">Leave Type</label>
						<div class="col-sm-3">
							<select ng-model="LeaveCategoryDetailID" name="nameLeaveCategoryDetail" id="idLeaveCategoryDetailID" class="form-control1">
								<option disabled selected value>-- Select Leave Type --</option>
								<option ng-repeat="a in categorydetails" value="{{a.ID}}">{{a.Name}}</option>
							</select>
						</div>
					</div>
                <div class="form-group"><label for="idLeaveListDescription" class="col-sm-2 control-label">Description</label><div class="col-sm-3"><textarea ng-model="LeaveListDescription" class="form-control" id="idLeaveListDescription" rows="3" placeholder="Please write description here..."></textarea></div></div>

				</form>
			</div>
		</div>
		<div class="bs-example" data-example-id="form-validation-states">
			<div class="panel-footer">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2">
						<button class="btn-primary btn" ng-click="myFunc()" ng-disabled="disableFlag">Apply Leave</button>
                        <!-- <button class="btn-success btn" ng-click="myFuncUpdate(x.ID, 1)" ng-disabled="disableFlag" >Update</button>					
						<button class="btn-danger btn" ng-click="ShowConfirmationBox(x.ID)" ng-disabled="disableFlag">Cancel</button> -->
						<label><font color={{MessageColor}}>{{Message}}</font></label>
					</div>
				</div>
				<br/>
				<div ng-show="confirmationBox">
						<br>Are you sure to cancel <font color=red><b>{{LeaveListDescription}}</b></font> leave approval?
						<button class="btn-danger btn" ng-click="myFuncUpdate(x.ID, 0)" ng-disabled="disableFlag">Yes</button>
						<button class="btn-default btn" ng-click="HideConfirmationBox()">No</button>
				</div>
				<br/>													
			</div>
		</div>
	</div>
	<div class="grid-form1">
		<div class="tab-content">
			<div class="tab-pane active">
				<div class="form-group" style="overflow-x:auto;">						
					<table>
						<tr>
							<th>Sr #</th>
							<th>From Date</th>
							<th>To Date</th>
                            <th>Leave Type</th>
							<th>Description</th>
                            <th>Created Date</th>
						</tr>
						<tr ng-repeat="x in names">
							<td>{{ $index + 1 }}
								<input 
								type="radio" 
								name="nameHolidayIDRadio" 
								ng-model="HolidayID" 
								id="HolidayIDRadio{{x.ID}}" 									
								value="{{x.Name}}" 
								ng-click="myFuncChecked(x.ID)">
								</input>							
							</td>
							<td>{{ x.FromDate }}</td>							
							<td>{{ x.ToDate}}</td>
                            <td>{{ x.LeaveTypeName }}</td>
                            <td>{{ x.Description }}</td>
							<td>{{ x.CreatedDate }}</td>
						</tr>
					</table>					
				</div>
			</div>
		</div>
	</div>										
</div>
