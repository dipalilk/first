<?php
class connectiondb
{
	function fnInitConn()
	{

		include_once("credential.php");
		$dbauth = new credential();
		$con = $dbauth->fnInitAuth();

		return $con;
	}
	function fnExecuteSelect($query)
	{		
		$con = $this->fnInitConn();
		
		$result = mysqli_query($con, $query);		
		$rows = array();
		if ($result)
		{
			while($r = mysqli_fetch_array($result)) {
				$rows[] = $r;
			}
		}
		mysqli_close($con);
		echo json_encode($rows);
	}
	function fnExecuteSelectWithoutJASON($query)
	{		
		$con = $this->fnInitConn();
		
		$result = mysqli_query($con, $query);		
		return $result;
	}	
	function fnExecuteUpdate($query)
	{
		$con = $this->fnInitConn();
		$result = mysqli_query($con, $query);
		
		$rc=0;
		if ($result)
			$rc=1;
				
		mysqli_close($con);		
		
		return $rc;		
	}
	function fnExecuteInsert($query)
	{		
		$con = $this->fnInitConn();							
		mysqli_query($con, $query);		
		$rc = mysqli_affected_rows($con);	
		mysqli_close($con);
		
		return $rc;
	}		
	function fnExecuteScalar($query)
	{
		$con = $this->fnInitConn();					
		
		$result = mysqli_query($con, $query);
		$retVal="";
		
		if ($result)
		{
			$row = $result->fetch_array();
			$retVal=$row[0];
		}
		mysqli_close($con);

		return $retVal;
	}	
	function fnExecuteDelete($query)
	{
		$con = $this->fnInitConn();			
		$result = mysqli_query($con, $query);
		$rc = mysqli_affected_rows($con);				
		mysqli_close($con);
		return $rc;
	}		
}//Class Closed

?>