<?php

$BusinessUserID=0; 
$CompanyID=0; 
$CreatedByID=0; 

include("clsDBConnection.php");
$db=new clsDBConnection();
$query="
SELECT 
    ll.ID, DATE_FORMAT(ll.FromDate, '%d-%b-%y') AS FromDate, 
    'Test' AS LeaveTypeName, 
    DATE_FORMAT(ll.ToDate, '%d-%b-%y') AS ToDate, 
    ll.Description, 
    DATE_FORMAT(ll.CreatedDate, '%d-%b-%y') AS CreatedDate 
FROM 
    LeaveList ll     
WHERE 
    ll.IsActive=1 
	AND ll.BusinessUserID=".$BusinessUserID." 
    AND ll.CompanyID=".$CompanyID." 
    AND ll.CreatedByID=".$CreatedByID." 
	";

//echo $query;	
$db->fnExecuteSelect($query);

?>