var app = angular.module('myApp', ['ngSanitize']);
app.controller('myCtrl', function($scope, $http) {
	
	$scope.disableFlag=true;	
    $scope.gCID = 0;
	$scope.confirmationBox=false;
	
	$scope.LeaveListFromDate=new Date();
	$scope.LeaveListToDate=new Date();
	
	$scope.categorydetails=[];
	
     $http.get("leave-list-select.php")
    .then(function (response) {$scope.names = response.data; $scope.disableFlag=false;});
	
$scope.myFuncChecked = function(cid) {
    $scope.disableFlag=true;
    $scope.gCID = cid;	
	//console.log (cid);
	var catname = {CID: cid};
	$http({method: 'POST', url: 'leave-list-select.php', headers: {'Content-Type': 'application/json'}, params:catname })
    .then(function (response) {
        $scope.holidaydetails = response.data;
        angular.forEach($scope.holidaydetails, function(item, key){
            if(item) {
                var dtHoliday=new Date(item.HolidayDateASIS);
                $scope.HolidayDate=dtHoliday;
                $scope.HolidayDescription=item.Description;
                $scope.HolidayState=item.State;
                $scope.HolidayCountry=item.Country;
            }
         });
        $scope.disableFlag=false;
    });	
}
$scope.myFunc = function() {
	$scope.disableFlag=true;
    var Indata = {
        ClientDate: new Date(),
		FromDate: $scope.LeaveListFromDate, 
		ToDate: $scope.LeaveListToDate, 
        LeaveType: $scope.LeaveCategoryDetailID,
        Description: $scope.LeaveListDescription, 
	};
	
	 $http({
			method: 'POST',
			url: 'leave-list-insert.php',
			headers: {
				'Content-Type': 'application/json'
			},
			params:Indata
		})
		.then(function (response) {
		var d = new Date().toLocaleTimeString().replace("/.*(\d{2}:\d{2}:\d{2}).*/", "$1");
	
		if (response.data>0) {
			$scope.Message = 'Saved - '+d;	
			$scope.MessageColor="green";
			$scope.myFuncRefresh();
		}
		else {
			$scope.Message = 'Failed - '+d;
			$scope.MessageColor="red";
			$scope.disableFlag=false;
		}
	});	
	$scope.disableFlag=false;
}
$scope.myFuncRefresh = function() {
     $http.get("leave-list-select.php")
	.then(function (response) {$scope.names = response.data; $scope.disableFlag=false;});
	
}
$scope.ShowConfirmationBox = function() {
	$scope.Message="";
	if ($scope.gCID==0) {
		$scope.Message = 'Select record to delete';
		$scope.MessageColor="blue";		
	}
	else {
		$scope.confirmationBox=true;
	}
}	
$scope.HideConfirmationBox = function() {
	$scope.confirmationBox=false;
}

});
 
