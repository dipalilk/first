<?php

class credential
{

	function fnInitAuth()
	{

		$con = mysqli_connect('localhost:1200', 'root', 'yourpassword'); //For local development

		if (!$con)
		{
			echo 'Unable to connect to the database server.';
			exit();
		}

		if (!mysqli_set_charset($con, 'utf8'))
		{
			echo 'Unable to set database connection encoding.';
			exit();
		}

		if (!mysqli_select_db($con, 'yourdatabasename')) //For local development
		{
			echo 'Unable to locate the database.';
			exit();
		}

		return $con;
	}
}

?>