<head>
<title>Jainam Software</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Jainam Software" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<link rel="SHORTCUT ICON" href="favicon.ico" />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<!-- Custom and plugin javascript -->
<link href="css/custom.css" rel="stylesheet">
<script src="js/screenfull.js"></script>
<script src="js/angular.min.js"></script>

<script>
var _$_e336=["\x53\x75\x70\x70\x6F\x72\x74\x65\x64\x2F\x61\x6C\x6C\x6F\x77\x65\x64\x3A\x20","\x65\x6E\x61\x62\x6C\x65\x64","\x74\x65\x78\x74","\x23\x73\x75\x70\x70\x6F\x72\x74\x65\x64","\x23\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x74\x6F\x67\x67\x6C\x65","\x63\x6C\x69\x63\x6B","\x23\x74\x6F\x67\x67\x6C\x65"];
$(function()
{
	$(_$_e336[3])[_$_e336[2]](_$_e336[0]+  !!screenfull[_$_e336[1]]);if(!screenfull[_$_e336[1]])
	{
		return false
	}
	//3
	$(_$_e336[7])[_$_e336[6]](function()
	{
		screenfull[_$_e336[5]]($(_$_e336[4])[0])
	}
	)
}
)
 
</script>
</head>

