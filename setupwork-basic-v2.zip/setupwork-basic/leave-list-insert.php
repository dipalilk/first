<?php

$BusinessUserID=0; 
$CompanyID=0; 
$CreatedByID=0; 
$ClientDate=''; if (isset($_GET['ClientDate'])) { $ClientDate=$_GET['ClientDate']; }
if ($ClientDate!='') { $ClientDate=substr($ClientDate, 0, 10); }

$FromDate=''; if (isset($_GET['FromDate'])) { $FromDate=str_replace("'", "", $_GET['FromDate']); }
if ($FromDate!='') { $FromDate=substr($FromDate, 0, 10); }
$ToDate=''; if (isset($_GET['ToDate'])) { $ToDate=str_replace("'", "", $_GET['ToDate']); }
if ($ToDate!='') { $ToDate=substr($ToDate, 0, 10); }


$LeaveType=290; if (isset($_GET['LeaveType'])) { $LeaveType=intval($_GET['LeaveType']); }
$Description=''; if (isset($_GET['Description'])) { $Description=str_replace("'", "", $_GET['Description']); }
$StatusID=295; //295 is for Apply //if (isset($_GET['StatusID'])) { $StatusID=intval($_GET['StatusID']); }


include("clsDBConnection.php");
$db=new clsDBConnection();

$query="insert into LeaveList (FromDate, ToDate, TypeID, Description, StatusID, IsActive, CompanyID, BusinessUserID, CreatedDate, CreatedByID ) values 
('".$FromDate."','".$ToDate."', '".$LeaveType."', '".$Description."', ".$StatusID.", 1, ".$CompanyID.", ".$BusinessUserID.", '".$ClientDate."', ".$CreatedByID.")";	

//echo $query;
$rc=$db->fnExecuteInsert($query);
echo $rc;
?>